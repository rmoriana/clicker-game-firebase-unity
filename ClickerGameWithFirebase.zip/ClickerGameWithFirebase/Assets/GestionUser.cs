﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Firebase;
using Firebase.Database;
using Firebase.Unity.Editor;

public class GestionUser : MonoBehaviour {

	//Variables para el ONGUI
	List<User> listaUsuarios = new List<User>();
	User flag;
    float barraExpVida, barraExpEscudo, barraExpMina, barraExpPower;

    int[] expVida = new int[10];
	int[] expPower = new int[10];
	int[] expMineral = new int[10];
	int[] expEscudo = new int[10];
	int costeExp;
	int numSubidasVida=0;
	int numSubidasMina=0;

    bool errorMsg;

	User user1 = new User ();
	DatabaseReference reference;

	//Establece conexión y la referencia a la base de datos y establece los valores iniciales (esto último se podría obviar tras la primera conexión).
	void Start () {
		FirebaseApp.DefaultInstance.SetEditorDatabaseUrl ("https://testpia-ec90d.firebaseio.com/");
		reference = FirebaseDatabase.DefaultInstance.RootReference;

		user1.NickName = "Raul";
		user1.Foto = 32;
		user1.Vida = 500;
		user1.Escudo = 0;
		user1.Power = 1;
		user1.Mineral = 1;
		user1.EXP_vida = 1;
		user1.EXP_Power = 1;
		user1.EXP_Mineral = 1;
		user1.EXP_escudo = 1;

		reference.Child ("Users").Child (user1.NickName);
		reference.Child ("Users").Child (user1.NickName).Child("Foto").SetValueAsync (user1.Foto);
		reference.Child ("Users").Child (user1.NickName).Child("Vida").SetValueAsync (user1.Vida);
		reference.Child ("Users").Child (user1.NickName).Child("EXP_vida").SetValueAsync (user1.EXP_vida);
		reference.Child ("Users").Child (user1.NickName).Child("Escudo").SetValueAsync (user1.Escudo);
		reference.Child ("Users").Child (user1.NickName).Child("EXP_escudo").SetValueAsync (user1.EXP_escudo);
		reference.Child ("Users").Child (user1.NickName).Child("Power").SetValueAsync (user1.Power);
		reference.Child ("Users").Child (user1.NickName).Child("EXP_Power").SetValueAsync (user1.EXP_Power);
		reference.Child ("Users").Child (user1.NickName).Child("Mineral").SetValueAsync (user1.Mineral);
		reference.Child ("Users").Child (user1.NickName).Child("EXP_Mineral").SetValueAsync (user1.EXP_Mineral);

		FirebaseDatabase.DefaultInstance.GetReference ("Users").ValueChanged += datosPersonales;

		arrayCero (expVida);
		arrayCero (expPower);
		arrayCero (expMineral);
		arrayCero (expEscudo);

	}

    //Muestra los nuevos datos de la base de datos tras detectar algún cambio.
	void datosPersonales(object sender, ValueChangedEventArgs args){
		
		if (args.DatabaseError != null) {
			Debug.Log (args.DatabaseError.Message);
			return;
		}

		listaUsuarios = new List<User> ();
		
		foreach (var childSnapshot in args.Snapshot.Children) {
			if (childSnapshot.Key == "Raul") {
				user1.Vida = int.Parse (childSnapshot.Child ("Vida").Value.ToString ());
			}
			if (int.Parse(childSnapshot.Child ("Vida").Value.ToString()) <= 0) {
				continue;			
			}
			flag = new User ();
			flag.NickName = childSnapshot.Key;
			flag.Mineral = int.Parse(childSnapshot.Child ("Mineral").Value.ToString());
			flag.Escudo = int.Parse(childSnapshot.Child ("Escudo").Value.ToString());
			flag.Vida = int.Parse(childSnapshot.Child ("Vida").Value.ToString());
			flag.Power = int.Parse(childSnapshot.Child ("Power").Value.ToString());
			listaUsuarios.Add (flag);
		}			
	}
	
	//Gestión de inputs.
	void Update () {
		if (Input.GetKeyDown (KeyCode.M)) { //AUMENTAR MINERALES
			user1.Mineral += numSubidasMina+1;
		}
		if (Input.GetKeyDown (KeyCode.Q)) { //EXPERIENCIA DE LA MINA DE MINERAL
			costeExp = numSubidasMina+1;
			if (user1.Mineral - costeExp >= 0) {
				for (int i = 0; i < 10; i++) {
					if (expMineral [i] == 0) {						
						expMineral [i] = 1;
                        barraExpMina = i + 1;
						user1.Mineral -= costeExp;
						break;
					}
				}
				if (expMineral [9] == 1) {
					user1.EXP_Mineral++;
					reference.Child ("Users").Child (user1.NickName).Child("EXP_Mineral").SetValueAsync (user1.EXP_Mineral);
					numSubidasMina++;
                    barraExpMina = 0;
					arrayCero (expMineral);
				}
			}else {
                errorMsg = true;
                Invoke("HideErrorMsg", 1);
            }

		} 
		if (Input.GetKeyDown (KeyCode.W)) { // POWER
			costeExp = user1.EXP_Power;
			if (user1.Mineral - costeExp >= 0) {
				for (int i = 0; i < 10; i++) {
					if (expPower [i] == 0) {
						expPower [i] = 1;
                        barraExpPower = i + 1;
                        user1.Mineral -= costeExp;
						break;
					}
				}
				if (expPower [9] == 1) {
					user1.Power++;
					reference.Child ("Users").Child (user1.NickName).Child ("Power").SetValueAsync (user1.Power);
					user1.EXP_Power++;
                    barraExpPower = 0;
                    arrayCero (expPower);
				}
			} else {
                errorMsg = true;
                Invoke("HideErrorMsg", 1);
            }

		}
		if (Input.GetKeyDown (KeyCode.E)) { // ESCUDO
			costeExp = user1.EXP_escudo;
			if (user1.Mineral - costeExp >= 0) {
				for (int i = 0; i < 10; i++) {
					if (expEscudo [i] == 0) {
						expEscudo [i] = 1;
                        barraExpEscudo = i + 1;
                        user1.Mineral -= costeExp;
						break;
					}
				}
				if (expEscudo [9] == 1) {
					user1.Escudo++;
					reference.Child ("Users").Child (user1.NickName).Child("Escudo").SetValueAsync (user1.Escudo);
					user1.EXP_escudo++;
                    barraExpEscudo = 0;
                    arrayCero (expEscudo);
				}
			} else {
                errorMsg = true;
                Invoke("HideErrorMsg", 1);
            }

		}
		if (Input.GetKeyDown (KeyCode.R)) { // VIDA
			costeExp = numSubidasVida+1;
			if (user1.Mineral - costeExp >= 0) {
				for (int i = 0; i < 10; i++) {
					if (expVida [i] == 0) {
						expVida [i] = 1;
                        barraExpVida = i + 1;
                        user1.Mineral -= costeExp;
						break;
					}
				}
				if (expVida [9] == 1) {
					user1.Vida++;
					reference.Child ("Users").Child (user1.NickName).Child("Vida").SetValueAsync (user1.Vida);
					numSubidasVida++;
                    barraExpVida = 0;
                    arrayCero (expVida);
				}
			}else {
                errorMsg = true;
                Invoke("HideErrorMsg", 1);
            }

		} 
			
	}

    //Pone a 0 los valores del array que recibe
	void arrayCero(int[] array){
		for (int i = 0; i < 10; i++) {
			array [i] = 0;
		}
	}

    //Interfaz con OnGUI
	void OnGUI(){

		//Jugador principal
		GUI.Label(new Rect(20,20,100,20),"Raul");
		GUI.Label(new Rect(20,40,100,20),"Vida: "+user1.Vida.ToString());
		GUI.Label(new Rect(20,60,100,20),"Escudo: "+user1.Escudo.ToString());
		GUI.Label(new Rect(20,80,100,20),"Power: "+user1.Power.ToString());
		GUI.Label(new Rect(20,100,100,20),"Mineral: "+user1.Mineral.ToString());
		GUI.HorizontalSlider(new Rect(120,40,100,20), barraExpVida, 0.0f, 10.0f);
		GUI.HorizontalSlider(new Rect(120,60,100,20), barraExpEscudo, 0.0f, 10.0f);
		GUI.HorizontalSlider(new Rect(120,80,100,20), barraExpPower, 0.0f, 10.0f);
		GUI.HorizontalSlider(new Rect(120,100,100,20), barraExpMina , 0.0f, 10.0f);
        GUI.Label(new Rect(230, 40, 250, 20), "R");
        GUI.Label(new Rect(230, 60, 250, 20), "E");
        GUI.Label(new Rect(230, 80, 250, 20), "W");
        GUI.Label(new Rect(230, 100, 250, 20), "Q");
        GUI.Label(new Rect(300, 40, 450, 20), "Pulsa M para conseguir un mineral.");
        if (errorMsg)
        {
            GUI.Label(new Rect(300, 60, 450, 20), "¡No tienes suficientes minerales!");
        }

        //Tabla
        GUI.Label(new Rect(130, 170, 60, 30), "Vida");
        GUI.Label(new Rect(190, 170, 60, 30), "Escudos");
        GUI.Label(new Rect(250, 170, 60, 30), "Poder");
        GUI.Label(new Rect(310, 170, 60, 30), "Mineral");

        GUI.Label(new Rect(Screen.width / 2 + 110, 170, 60, 30), "Vida");
        GUI.Label(new Rect(Screen.width / 2 + 170, 170, 60, 30), "Escudos");
        GUI.Label(new Rect(Screen.width / 2 + 230, 170, 60, 30), "Poder");
        GUI.Label(new Rect(Screen.width / 2 + 290, 170, 60, 30), "Mineral");

        //El resto de jugadores
        int posX = 20;
        int posY = 0;
        for (int numUsers = 0; numUsers < listaUsuarios.Count; numUsers++) {
			if(numUsers >= 8) {
                if(numUsers == 8)
                {
                    posY = 0;
                }
                posX = Screen.width / 2;
                
            }
            else
            {
                posY = numUsers;
            }
			if (GUI.Button (new Rect (posX, 200+(posY*40), 100,30),listaUsuarios[numUsers].NickName)) {
				attackPlayer (numUsers);
			}
            GUI.Label(new Rect(posX + 110, 200 + (posY * 40), 60, 30), listaUsuarios[numUsers].Vida.ToString());
            GUI.Label(new Rect(posX + 170, 200 + (posY * 40), 60, 30), listaUsuarios[numUsers].Escudo.ToString());
            GUI.Label(new Rect(posX + 230, 200 + (posY * 40), 60, 30), listaUsuarios[numUsers].Power.ToString());
            GUI.Label(new Rect(posX + 290, 200 + (posY * 40), 60, 30), listaUsuarios[numUsers].Mineral.ToString());
            posY++;
        }
    }

    //Gestiona los ataques a otros jugadores
    void attackPlayer(int numUser)
    {
		int vidaUser = listaUsuarios [numUser].Vida;
		int escudoUser = listaUsuarios [numUser].Escudo;
		int poderAtaque = user1.Power;
		int vidaRestante;

		if (escudoUser - poderAtaque < 0) {
			vidaRestante = vidaUser - (poderAtaque - escudoUser);
			reference.Child ("Users").Child (listaUsuarios[numUser].NickName).Child("Vida").SetValueAsync (vidaRestante);

		}						
    }

    private void HideErrorMsg()
    {
        errorMsg = false;
    }
}
