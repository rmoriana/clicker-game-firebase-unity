﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class User{

	public string NickName { get; set; }
	public int Foto { get; set; }
	public int Vida { get; set; }
	public int EXP_vida { get; set; }
	public int Escudo { get; set; }
	public int EXP_escudo { get; set; }
	public int Power { get; set; }
	public int EXP_Power { get; set; }
	public int Mineral { get; set; }
	public int EXP_Mineral { get; set; }


}
